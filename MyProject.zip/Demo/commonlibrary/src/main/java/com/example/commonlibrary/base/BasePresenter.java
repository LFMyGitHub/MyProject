package com.example.commonlibrary.base;

/**
 * MVP中Presenter层基类接口
 */
public interface BasePresenter {
}
