2020-03-30
创建一个空项目
根目录下创建ReadMe文件

根目录下创建通用配置config.gradle

根目录gradle内引用通用配置config.gradle

创建BaseModule/CommonModule/MainModule

在gradle.properties配置是否单独编译的开关

单独编译开关设置后在需要单独编译的模块gradle中添加单独编译判断

在app_module的gradle中添加不同开关状态下是否需要引用模块的判断

在不同开关状态下设置不同AndroidManifest.xml文件的引用

添加Arouter依赖(layout的命名不要重复)



